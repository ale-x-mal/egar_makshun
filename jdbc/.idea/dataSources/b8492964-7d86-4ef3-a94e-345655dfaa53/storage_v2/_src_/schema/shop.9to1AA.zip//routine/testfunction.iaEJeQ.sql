create function testFunction()
  returns varchar(30)
  BEGIN
    DECLARE result varchar(30);
 
   
 SET result = 'Test function is OK!!!';
 
 RETURN (result); 
END;

